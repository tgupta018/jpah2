package com.demo.spring.service.membership;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCustomerMembershipServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
