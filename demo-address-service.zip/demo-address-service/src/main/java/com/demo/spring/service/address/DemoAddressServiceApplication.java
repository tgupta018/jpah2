package com.demo.spring.service.address;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAddressServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAddressServiceApplication.class, args);
	}

}
