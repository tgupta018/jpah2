package com.demo.spring.service.payments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPaymentsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
