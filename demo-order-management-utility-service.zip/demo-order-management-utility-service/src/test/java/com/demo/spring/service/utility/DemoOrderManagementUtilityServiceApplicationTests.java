package com.demo.spring.service.utility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOrderManagementUtilityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
