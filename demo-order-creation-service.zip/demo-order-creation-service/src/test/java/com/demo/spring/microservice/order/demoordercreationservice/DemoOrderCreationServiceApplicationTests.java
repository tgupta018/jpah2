package com.demo.spring.microservice.order.demoordercreationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOrderCreationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
