package com.demo.spring.service.warehouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoWarehouseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
