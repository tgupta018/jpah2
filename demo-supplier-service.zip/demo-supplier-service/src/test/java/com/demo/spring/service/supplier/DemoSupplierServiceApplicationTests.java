package com.demo.spring.service.supplier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSupplierServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
