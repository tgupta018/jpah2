package com.demo.spring.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderManagementSampleAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
