package com.demo.spring.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderManagementSampleAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderManagementSampleAppApplication.class, args);
	}

}
