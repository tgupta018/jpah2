package com.demo.spring.service.persons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPersonsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
