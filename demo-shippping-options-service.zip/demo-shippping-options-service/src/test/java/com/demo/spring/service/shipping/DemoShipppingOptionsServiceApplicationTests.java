package com.demo.spring.service.shipping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoShipppingOptionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
