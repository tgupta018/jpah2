package com.demo.spring.service.shipping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoShipppingOptionsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoShipppingOptionsServiceApplication.class, args);
	}

}
