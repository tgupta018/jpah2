# Spring Boot Web Application
##Using H2 and Oracle for a Spring Boot Web Application

How to use H2 and Oracle with a Spring Boot Web Application using Spring Framework profiles.

You can see the full blog post about using Spring Boot with H2 and Oracle at  [Spring Framework Guru](https://springframework.guru/using-h2-and-oracle-with-spring-boot/)

