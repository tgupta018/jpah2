CREATE TABLE EMPLOYEE
        (
        id NUMBER(10) NOT NULL,
        name VARCHAR2(50) NOT NULL,
        PRIMARY KEY(id)
        );